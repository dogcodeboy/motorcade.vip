<?php if (!defined('ABSPATH')) { exit; } ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="mc-topbar">
  <div class="mc-wrap">
    <div class="mc-nav">
      <a class="mc-logo" href="<?php echo esc_url(home_url('/')); ?>">
        <?php
          $logo = mc_asset_url('logo.png');
        ?>
        <img src="<?php echo esc_url($logo); ?>" alt="Motorcade" onerror="this.style.display='none';">
        <span>Motorcade</span>
      </a>

      <nav class="mc-menu" aria-label="Primary">
        <?php
          if (has_nav_menu('primary')) {
            wp_nav_menu([
              'theme_location' => 'primary',
              'container' => false,
              'items_wrap' => '%3$s',
              'fallback_cb' => false,
              'depth' => 1,
            ]);
          } else {
            mc_menu_fallback();
          }
        ?>
        <a class="mc-cta" href="<?php echo esc_url(home_url('/contact/')); ?>">Request a Quote</a>
      </nav>
    </div>
  </div>
</header>
