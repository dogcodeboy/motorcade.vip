<?php
if (!defined('ABSPATH')) { exit; }
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="mc-wrap" style="padding:18px 20px;">
  <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;">
    <a href="<?php echo esc_url(home_url('/')); ?>" style="display:flex;align-items:center;gap:10px;text-decoration:none;color:inherit;">
      <span style="font-weight:800;letter-spacing:.4px;">Motorcade</span>
    </a>
    <nav style="display:flex;gap:14px;flex-wrap:wrap;">
      <a href="<?php echo esc_url(home_url('/services')); ?>">Services</a>
      <a href="<?php echo esc_url(home_url('/security-assessment')); ?>">Assessment</a>
      <a href="<?php echo esc_url(home_url('/about')); ?>">About</a>
      <a href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a>
    </nav>
  </div>
</header>
