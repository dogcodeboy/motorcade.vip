<?php get_header(); ?>
<h1>Motorcade</h1>
<?php get_footer(); ?>