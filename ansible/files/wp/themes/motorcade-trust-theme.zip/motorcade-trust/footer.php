<?php if (!defined('ABSPATH')) { exit; } ?>
<footer class="mc-wrap" style="padding:34px 20px 50px;color:var(--mc-muted);border-top:1px solid var(--mc-border);">
  <div style="display:flex;flex-wrap:wrap;gap:18px;align-items:center;justify-content:space-between;">
    <div>&copy; <?php echo date('Y'); ?> Motorcade. All rights reserved.</div>
    <div style="display:flex;gap:12px;">
      <a href="<?php echo esc_url(home_url('/privacy')); ?>">Privacy</a>
      <a href="<?php echo esc_url(home_url('/terms')); ?>">Terms</a>
    </div>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
