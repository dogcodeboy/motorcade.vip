<?php if (!defined('ABSPATH')) { exit; } ?>
<footer class="mc-footer">
  <div class="mc-wrap">
    <div class="row">
      <div>
        <strong style="color:#fff">Motorcade Security Solutions</strong><br>
        <span class="mc-small">Executive protection • Site security • Transport</span>
      </div>
      <div class="mc-small">
        <a href="<?php echo esc_url(home_url('/contact/')); ?>">Contact</a> ·
        <a href="<?php echo esc_url(home_url('/services/')); ?>">Services</a>
      </div>
    </div>
    <div class="mc-small" style="margin-top:12px;">
      © <?php echo esc_html(date('Y')); ?> Motorcade. All rights reserved.
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
