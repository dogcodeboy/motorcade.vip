<?php
if (!defined('ABSPATH')) { exit; }

function motorcade_trust_setup() {
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption']);
}
add_action('after_setup_theme', 'motorcade_trust_setup');

function motorcade_trust_assets() {
  wp_enqueue_style('motorcade-trust-style', get_stylesheet_uri(), [], '1.1.2');
}
add_action('wp_enqueue_scripts', 'motorcade_trust_assets');

/**
 * Returns a URL inside wp-content/uploads/motorcade/
 * Example: motorcade_asset_url('hero-executive-protection.jpg')
 */
function motorcade_asset_url($filename) {
  $u = wp_upload_dir();
  $base = trailingslashit($u['baseurl']) . 'motorcade/';
  return $base . ltrim($filename, '/');
}
