<?php
// Motorcade Trust theme functions
