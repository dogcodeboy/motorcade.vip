<?php
if (!defined('ABSPATH')) { exit; }

add_action('after_setup_theme', function () {
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  register_nav_menus([
    'primary' => __('Primary Menu', 'motorcade-trust'),
  ]);
});

add_action('wp_enqueue_scripts', function () {
  wp_enqueue_style('motorcade-trust', get_stylesheet_uri(), [], '1.2.0');
});

/**
 * Return a URL for an image that may exist either:
 *  1) As an attachment in the Media Library (preferred), OR
 *  2) As a file in /wp-content/uploads/motorcade/<filename>
 *
 * This allows Ansible to deploy static files while still supporting Media imports.
 */
function mc_asset_url($filename) {
  $filename = ltrim($filename, '/');
  $cached = get_transient('mc_asset_' . md5($filename));
  if ($cached) return $cached;

  // Try Media Library lookup by attached file (fast + reliable if imported).
  $like = '%' . $filename;
  $q = new WP_Query([
    'post_type'      => 'attachment',
    'post_status'    => 'inherit',
    'posts_per_page' => 1,
    'fields'         => 'ids',
    'meta_query'     => [[
      'key'     => '_wp_attached_file',
      'value'   => $like,
      'compare' => 'LIKE',
    ]],
  ]);
  if (!empty($q->posts)) {
    $id = (int)$q->posts[0];
    $url = wp_get_attachment_url($id);
    if ($url) {
      set_transient('mc_asset_' . md5($filename), $url, 12 * HOUR_IN_SECONDS);
      return $url;
    }
  }

  // Fallback: direct uploads path (works even if not imported).
  $uploads = wp_upload_dir();
  $url = trailingslashit($uploads['baseurl']) . 'motorcade/' . basename($filename);
  set_transient('mc_asset_' . md5($filename), $url, 12 * HOUR_IN_SECONDS);
  return $url;
}

function mc_menu_fallback() {
  echo '<a href="' . esc_url(home_url('/')) . '">Home</a>';
  echo '<a href="' . esc_url(home_url('/services/')) . '">Services</a>';
  echo '<a href="' . esc_url(home_url('/contact/')) . '">Contact</a>';
}

