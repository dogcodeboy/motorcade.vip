<?php if (!defined('ABSPATH')) { exit; } ?>
<?php get_header(); ?>

<main>
  <section class="mc-hero">
    <div class="mc-wrap">
      <div class="mc-hero-grid">
        <div>
          <div class="mc-eyebrow"><span class="dot"></span> Private Security • Texas-first</div>
          <h1 class="mc-h1">Security that feels professional, calm, and in control.</h1>
          <p class="mc-sub">
            Executive protection, armed drivers, escort vehicles, and site security — built for reliability,
            discretion, and clear command structure.
          </p>
          <div class="mc-hero-actions">
            <a class="mc-btn mc-btn-primary" href="<?php echo esc_url(home_url('/contact/')); ?>">Get a Quote</a>
            <a class="mc-btn" href="<?php echo esc_url(home_url('/services/')); ?>">View Services</a>
          </div>
          <div class="mc-badges">
            <span class="mc-badge">Licensed & insured</span>
            <span class="mc-badge">24/7 dispatch-ready</span>
            <span class="mc-badge">Professional uniforms</span>
          </div>
        </div>

        <div class="mc-hero-card">
          <?php $hero = mc_asset_url('hero-executive-protection.jpg'); ?>
          <div class="img" style="background-image:url('<?php echo esc_url($hero); ?>');"></div>
          <div class="body">
            <strong>Executive Protection</strong><br>
            <span class="mc-small" style="color:var(--muted)">Low-profile coverage with proactive risk awareness.</span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="mc-section">
    <div class="mc-wrap">
      <div class="mc-grid3">
        <div class="mc-card">
          <h3>Fast response</h3>
          <p>Deploy-ready teams with clear escalation paths and supervisor oversight.</p>
        </div>
        <div class="mc-card">
          <h3>Discreet presence</h3>
          <p>Professional posture, calm communication, and minimal disruption.</p>
        </div>
        <div class="mc-card">
          <h3>Documented operations</h3>
          <p>Post orders, incident reporting, and shift handoffs built into the workflow.</p>
        </div>
      </div>

      <div class="mc-svc">
        <?php $img1 = mc_asset_url('services-executive.jpg'); ?>
        <div class="tile">
          <div class="img" style="background-image:url('<?php echo esc_url($img1); ?>');"></div>
          <div class="body">
            <div class="k">Executive Protection</div>
            <strong>Close protection and armed drivers</strong>
            <p class="mc-small" style="color:var(--muted)">Advance planning, route strategy, and smooth client experience.</p>
          </div>
        </div>

        <?php $img2 = mc_asset_url('services-site-security.jpg'); ?>
        <div class="tile">
          <div class="img" style="background-image:url('<?php echo esc_url($img2); ?>');"></div>
          <div class="body">
            <div class="k">Site Security</div>
            <strong>Visible deterrence for businesses</strong>
            <p class="mc-small" style="color:var(--muted)">Uniformed coverage with clear reporting and post compliance.</p>
          </div>
        </div>

        <?php $img3 = mc_asset_url('services-transport.jpg'); ?>
        <div class="tile">
          <div class="img" style="background-image:url('<?php echo esc_url($img3); ?>');"></div>
          <div class="body">
            <div class="k">Transport & Escorts</div>
            <strong>Escort vehicles and armed delivery</strong>
            <p class="mc-small" style="color:var(--muted)">Coordinated movement with real-time monitoring.</p>
          </div>
        </div>

        <?php $img4 = mc_asset_url('cta-contact.jpg'); ?>
        <div class="tile">
          <div class="img" style="background-image:url('<?php echo esc_url($img4); ?>');"></div>
          <div class="body">
            <div class="k">Talk to dispatch</div>
            <strong>Request a quote or schedule coverage</strong>
            <p class="mc-small" style="color:var(--muted)">We’ll confirm scope, location, and staffing needs quickly.</p>
            <div style="margin-top:10px">
              <a class="mc-btn mc-btn-primary" href="<?php echo esc_url(home_url('/contact/')); ?>">Contact</a>
            </div>
          </div>
        </div>
      </div>

      <section class="mc-section">
        <div class="mc-wrap">
          <?php
          // Also render page content if Home page has additional blocks/content.
          if (have_posts()) : while (have_posts()) : the_post();
            the_content();
          endwhile; endif;
          ?>
        </div>
      </section>
    </div>
  </section>
</main>

<?php get_footer(); ?>
