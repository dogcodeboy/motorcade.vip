<?php
if (!defined('ABSPATH')) { exit; }
get_header();

$hero = esc_url( motorcade_asset_url('hero-executive-protection.jpg') );
$svc1 = esc_url( motorcade_asset_url('services-executive.jpg') );
$svc2 = esc_url( motorcade_asset_url('services-site-security.jpg') );
$svc3 = esc_url( motorcade_asset_url('services-transport.jpg') );
$about = esc_url( motorcade_asset_url('about-team.jpg') );
$cta = esc_url( motorcade_asset_url('cta-contact.jpg') );
?>

<section class="mc-hero" style="background-image:url('<?php echo $hero; ?>');">
  <div class="mc-wrap mc-hero-inner">
    <h1>Elite security, built for real-world risk.</h1>
    <p>
      Motorcade provides executive protection, armed transport, and site security with
      disciplined personnel, modern dispatch, and a client-first approach.
    </p>
    <a class="mc-btn" href="<?php echo esc_url(home_url('/contact')); ?>">Request a Quote</a>
    <a class="mc-btn secondary" href="<?php echo esc_url(home_url('/services')); ?>">View Services</a>
  </div>
</section>

<section class="mc-section">
  <div class="mc-wrap">
    <h2 style="margin:0 0 16px;">Services</h2>
    <div class="mc-grid">
      <article class="mc-card">
        <img src="<?php echo $svc1; ?>" alt="Executive Protection">
        <div class="mc-card-body">
          <h3>Executive Protection</h3>
          <p>Professional close protection for principals, families, and VIP travel.</p>
        </div>
      </article>
      <article class="mc-card">
        <img src="<?php echo $svc2; ?>" alt="Site Security">
        <div class="mc-card-body">
          <h3>Site Security</h3>
          <p>Guards and supervisors for facilities, events, and 24/7 coverage.</p>
        </div>
      </article>
      <article class="mc-card">
        <img src="<?php echo $svc3; ?>" alt="Armed Transport">
        <div class="mc-card-body">
          <h3>Armed Transport</h3>
          <p>High-trust escort and transport with secure procedures and comms.</p>
        </div>
      </article>
    </div>
  </div>
</section>

<section class="mc-section" style="padding-top:0;">
  <div class="mc-wrap mc-split">
    <div>
      <h2 style="margin:0 0 10px;">A security partner you can verify.</h2>
      <p style="color:var(--mc-muted);margin:0 0 12px;">
        We focus on accountability, documentation, and consistent service delivery — the fundamentals that make security effective.
      </p>
      <a class="mc-btn secondary" href="<?php echo esc_url(home_url('/about')); ?>">Learn more</a>
    </div>
    <div>
      <img src="<?php echo $about; ?>" alt="Motorcade team">
    </div>
  </div>
</section>

<section class="mc-section" style="border-top:1px solid var(--mc-border);">
  <div class="mc-wrap mc-split">
    <div>
      <img src="<?php echo $cta; ?>" alt="Contact Motorcade">
    </div>
    <div>
      <h2 style="margin:0 0 10px;">Need coverage fast?</h2>
      <p style="color:var(--mc-muted);margin:0 0 14px;">
        Tell us your location, timeline, and risk profile. We'll respond with staffing options and next steps.
      </p>
      <a class="mc-btn" href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a>
    </div>
  </div>
</section>

<main class="mc-wrap" style="padding:42px 20px 20px;">
<?php
if (have_posts()) :
  while (have_posts()) : the_post();
    if (trim(get_the_content()) !== '') {
      the_content();
    }
  endwhile;
endif;
?>
</main>

<?php get_footer(); ?>
