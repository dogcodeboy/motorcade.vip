<?php if (!defined('ABSPATH')) { exit; } ?>
<?php get_header(); ?>
<main class="mc-section">
  <div class="mc-wrap">
    <?php if (have_posts()): while (have_posts()): the_post(); ?>
      <h1 style="margin-top:0"><?php the_title(); ?></h1>
      <div style="color:var(--muted)"><?php the_content(); ?></div>
    <?php endwhile; endif; ?>
  </div>
</main>
<?php get_footer(); ?>
