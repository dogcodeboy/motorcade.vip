Motorcade Assets Bundle (placeholder)

Place your site image assets (hero images, icons, logos) in this zip so Ansible can deploy them to:
  /var/www/motorcade/wp-content/uploads/motorcade/

Expected structure inside this zip (example):
  hero/
    hero-1.jpg
  logos/
    motorcade-logo.svg
  icons/
    shield.svg

Then set deploy_assets=true when running Playbook 19.

This placeholder exists only to create the repo path:
  ansible/files/wp/assets/motorcade-assets.zip
